package edu.ifmt.cobrancaifmt2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cobrancaifmt2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
