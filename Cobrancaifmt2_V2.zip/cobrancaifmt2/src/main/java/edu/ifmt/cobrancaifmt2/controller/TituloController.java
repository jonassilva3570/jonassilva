package edu.ifmt.cobrancaifmt2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.ifmt.cobrancaifmt2.model.Titulo;
import edu.ifmt.cobrancaifmt2.repository.Titulos;

@Controller // Anotacao controller do Spring
@RequestMapping("/titulos")
class TituloController {

	@RequestMapping("/novo") // mapeamento da url
	public String novo() { // metodo que retorna uma Spring com nome da view
		return "CadastroTitulo";

	}

	@RequestMapping(method = RequestMethod.POST)
	public String salvar(Titulo titulo) {
		titulos.save(titulo);
		
		return "CadastroTitulo";
		
	}
	
	@Autowired //anotacao que ira injetar dependencia
	private Titulos titulos;

}
