package edu.ifmt.cobrancaifmt2.model;

	public enum StatusTitulo {
		PENDENTE, RECEBIDO;

		

	}

	
	

