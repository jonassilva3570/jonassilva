package com.javaweb.funcionarios.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.javaweb.funcionarios.model.Funcionario;
import com.javaweb.funcionarios.services.FuncionarioService;


public class FuncionarioController {
	
	@Autowired
	private FuncionarioService funcionarioService;
	// Mostra lista de funcionários
	
	@GetMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("listFuncionarios", funcionarioService.getAllFuncionarios());
		return "index";
	}
	
	@GetMapping("/showNewFuncionarioForm")
	public String showNewFuncionarioForm (Model model) {
		Funcionario funcionario = new Funcionario();
		model.addAttribute("funcionario", funcionario);
		return "new_funcionario";
	}
	
	@PostMapping("/salvarFuncionario")
	public String salvarFuncionario(@ModelAttribute("funcionario") Funcionario funcionario) {
		// Adiciona funcionario no banco de dados
		
		funcionarioService.salvarFuncionario(funcionario);
		return "redirect:/";
		
	}
	
	@GetMapping("/showFormAtualizar/{id}")
	public String showFormAtualizar(@PathVariable( value = "id") long id, Model model) {
		
		//obtém funcionario do serviço
		
		Funcionario funcionario = funcionarioService.getFuncionarioPorId(id);
		
		model.addAttribute("funcionario", funcionario);
		return "update_funcionario";
		
	}
	
	@GetMapping("/ExcluirFuncionario/{id}")
	public String ExcluirFuncionario(@PathVariable (value = "id")long id) {
		
		//Chama o método de Exclusão
		
		this.funcionarioService.ExcluirFuncionarioPorId(id);
		return "redirect:/";
		
	}

}
