package com.javaweb.funcionarios.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javaweb.funcionarios.model.Funcionario;
import com.javaweb.funcionarios.repository.FuncionarioRepository;


@Service
public class FuncionarioServiceImpl implements FuncionarioService{
	
    @Autowired
    private FuncionarioRepository funcionarioRepository;
    
	@Override
	public List<Funcionario> getAllFuncionarios() {
		return funcionarioRepository.findAll();
		
	}

	@Override
	public void salvarFuncionario(Funcionario funcionario) {
		this.funcionarioRepository.save(funcionario);
		
	}
	
	public Funcionario getFuncionarioPorId(long id) {
		Optional<Funcionario> optional = funcionarioRepository.findById(id);
		Funcionario funcionario = null;
		if(optional.isPresent()) {
			funcionario = optional.get();
			
		}else {
			throw new RuntimeException("Funcionário não encontrado pelo id ::" + id);
		}
		return funcionario;
		
	}

	@Override
	public void ExcluirFuncionarioPorId(long id) {
		this.funcionarioRepository.deleteById(id);
		
	}
	
	
	

}
