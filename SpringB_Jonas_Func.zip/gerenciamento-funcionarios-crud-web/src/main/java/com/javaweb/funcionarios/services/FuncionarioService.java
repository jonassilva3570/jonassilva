package com.javaweb.funcionarios.services;

import java.util.List;

import com.javaweb.funcionarios.model.Funcionario;

public interface FuncionarioService {
	List<Funcionario> getAllFuncionarios();
	void salvarFuncionario(Funcionario funcionario);
	Funcionario getFuncionarioPorId(long id);
	void ExcluirFuncionarioPorId(long id);

}
